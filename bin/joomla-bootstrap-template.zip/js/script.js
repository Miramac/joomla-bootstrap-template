//script.js

//Remove stuff for the demo site (use it only for the demo!)
$(function() {
	//Print and mail feature
	$('ul.actions').remove();
	//Breadcrumb Text "You are here:" 
	$('span.showHere').remove();
});